#include "data_structs.h"

int escreveIndice(char *arquivoIndice, RegistroIndice **DadosIndice, int tamanhoArquivoIndice);
int compararIndicePorID(const void *a, const void *b);