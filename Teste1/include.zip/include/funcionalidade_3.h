#ifndef FUNCIONALIDADE_3_H
#define FUNCIONALIDADE_3_H
#include "data_structs.h"
int lerArquivoBinario(char *nomeDoArquivo);

#endif //FUNCIONALIDADE_3_H