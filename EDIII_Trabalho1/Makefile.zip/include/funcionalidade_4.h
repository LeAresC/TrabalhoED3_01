#ifndef FUNCIONALIDADE_4_H
#define FUNCIONALIDADE_4_H
#include "data_structs.h"
int buscaNDados(char *arquivoDados, char *arquivoIndice, int N);

#endif //FUNCIONALIDADE_4_H