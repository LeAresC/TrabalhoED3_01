#ifndef UTILIDADES_H
#define UTILIDADES_H

void scanQuoteString(char *str);
void binarioNaTela(char *nomeArquivoBinario);
#endif 