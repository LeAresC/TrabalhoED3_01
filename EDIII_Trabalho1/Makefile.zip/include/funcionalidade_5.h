#ifndef FUNCIONALIDADE_5_H
#define FUNCIONALIDADE_5_H

int removeArquivoPessoa(char *arquivoDados, char *arquivoIndice, int N);
#endif //FUNCIONALIDADE_5_H