#ifndef CRIAR_TABELA_SEGUE_H
#define CRIAR_TABELA_SEGUE_H

int criarTabelaSegue(const char *nomeArquivoCsv, const char *nomeArquivoDados);

#endif // CRIAR_TABELA_SEGUE_H