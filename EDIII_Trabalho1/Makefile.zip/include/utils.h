#ifndef UTILS_H
#define UTILS_H

char* obterProximoCampo(char **linha);
int compararRegistrosIndice(const void *a, const void *b);

#endif // UTILS_H