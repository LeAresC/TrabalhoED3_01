#ifndef ORDENA_SEGUE_H
#define ORDENA_SEGUE_H

int ordenaSegue(const char *nomeArquivoDesordenado, const char *nomeArquivoOrdenado);

#endif // ORDENA_SEGUE_H