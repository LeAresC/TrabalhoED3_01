int buscaAmizades(char *arqPessoa, char *arqIndex, char *arqSegue);
void liberaRegistroIndice(RegistroIndice **DadosIndice, int qtdPessoas);
void liberaListaAdjacencia(Lista *ListaAdjacencia, int qtdPessoas);