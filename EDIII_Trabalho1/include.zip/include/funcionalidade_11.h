int buscaAmizades(char *arqPessoa, char *arqIndex, char *arqSegue);
void liberaListaAdjacencia(Lista *ListaAdjacencia, int qtdPessoas);