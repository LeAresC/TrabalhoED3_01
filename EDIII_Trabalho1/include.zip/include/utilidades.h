#ifndef UTILIDADES_H
#define UTILIDADES_H

#include "data_structs.h"

void scanQuoteString(char *str);
void binarioNaTela(char *nomeArquivoBinario);

#endif 