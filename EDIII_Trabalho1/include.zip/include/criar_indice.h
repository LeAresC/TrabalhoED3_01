#ifndef CRIAR_INDICE_H
#define CRIAR_INDICE_H

#include "data_structs.h"

int criarIndice(const char *nomeArquivo);

#endif // CRIAR_INDICE_H
