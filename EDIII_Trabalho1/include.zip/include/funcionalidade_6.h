int insereNoFinal(char *arquivoDados, char *arquivoIndice, int N);
RegistroPessoa *preparaRegistro(char *nomePessoa, char *nomeUsuario, char *valorId, char *idadePessoa);