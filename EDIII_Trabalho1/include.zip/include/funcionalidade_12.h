int buscaAmizadesTransposto(char *arqPessoa, char *arqIndex, char *arqSegue);
