#ifndef JUNTA_PESSOA_SEGUE_H
#define JUNTA_PESSOA_SEGUE_H

int juntaPessoaSegue(const char *arquivoPessoa, const char *arquivoSegue, const char *arquivoIndice, int n);

#endif // JUNTA_PESSOA_SEGUE_H